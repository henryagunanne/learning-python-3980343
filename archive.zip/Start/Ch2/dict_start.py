# LinkedIn Learning Python course by Joe Marini
# Example file for complex types


# Dictionary: a key-value data structure


# dictionaries are accessed via keys


# you can also set dictionary data by creating a new key


# Trying to access a nonexistent key will produce an error


# To avoid this, you can use the "in" operator to see if a key exists


# You can retrieve all of the keys and values from a dictionary


# You can also iterate over all the items in a dictionary
